
public class TestWarnings {

}
